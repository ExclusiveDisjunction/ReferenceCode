#pragma once

#include "ToolEditor.h"

#include "..\UI\UICommon.h"
#include <Windows.h>

namespace Mason::UI::Editors
{
	class MiniEditorHost
	{
	private:
		HWND _Base;

		ToolEditor* _Target;
	public:


	};
}