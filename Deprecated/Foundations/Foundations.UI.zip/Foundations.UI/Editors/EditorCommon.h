#pragma once

#include "..\Common.h"

namespace Core::Editors
{
	static unsigned long long AllEditorsCode;
}