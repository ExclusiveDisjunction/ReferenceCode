#pragma once

#include "UICommon.h"
#include <d2d1.h>
#pragma comment(lib, "d2d1.lib")

//Dll Entry Point
bool __stdcall DllMain(HINSTANCE, DWORD, LPVOID);

namespace Core::UI
{
    String UI_API GetText(HWND Window);
    void UI_API SetText(HWND Window, String New);

    class UI_API Control
    {
    private:
        static LRESULT __stdcall CommonWndProc(HWND Window, UINT Message, WPARAM wp, LPARAM lp);
        static bool RegisterAtom(HINSTANCE ins);
        static ATOM _ThisAtom;
        static ID2D1Factory* Factory;

        HWND _Base = nullptr;
        bool IsEnabled = true;
        ID2D1HwndRenderTarget* RenderTarget = nullptr;

    protected:
        ATOM GetAtom() const;

        virtual bool FocusOnClick() const { return true; }
    public:
        Control(HINSTANCE ins);
        virtual ~Control();

        // !! IMPORTANT !! The DllMain function is responsible for cleaning, starting, and closing out the ATOM.
        friend bool __stdcall ::DllMain(HINSTANCE, DWORD, LPVOID);

        //Properties

        //Basic Management
        virtual void OnPaint() { }
        virtual void OnDestroy() { }
        virtual void OnCreate(CREATESTRUCT* create) {}

        //User Input
        virtual void OnKeyDown(WPARAM key);
        virtual void OnChar(wchar_t Character, int RepeatCount, int ScanCode, bool ExtendedKey, bool PrevStatePressed, bool IsBeingReleased) { }
        virtual void OnClick() {  }
        virtual void OnDoubleClick() { SendMessage(GetParent(_Base), WM_LBUTTONDBLCLK, 0, 0); }
        virtual void OnRDoubleClick() { SendMessage(GetParent(_Base), WM_RBUTTONDBLCLK, 0, 0); }
        virtual void OnMouseUp() { }
        virtual void OnRightClick() { SendMessage(GetParent(_Base), WM_RBUTTONDOWN, 0, 0); }

        //Windows Events
        virtual void OnTimerTick(long TimerID) { }
        virtual void OnSize(LONG width, LONG height);
        virtual void OnMove(LONG x, LONG y);
        virtual void GotFocus() { }
        virtual void LostFocus() { }
        virtual void OnCommand(WPARAM ID, LPARAM lp) { SendMessage(GetParent(_Base), WM_COMMAND, ID, lp); }

        bool Enabled();
        void Enabled(bool New);

        virtual void Redraw();

        HWND GetBase() const { return _Base; }
        explicit operator HWND() const
        {
            return _Base;
        }
    };
}