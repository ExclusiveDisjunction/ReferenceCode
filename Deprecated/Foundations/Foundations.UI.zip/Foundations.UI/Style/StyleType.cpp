#include "StyleType.h"

using namespace Core;
using namespace Core::UI;

StyleType::~StyleType()
{
	//Not used in this release, but may be used later on.
}