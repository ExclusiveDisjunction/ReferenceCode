#include "Control.h"

#include <iostream>

namespace Core::UI
{
    String GetText(HWND Window)
    {
        int TextLen = static_cast<int>(GetWindowTextLength(Window)) + 1;
        TCHAR* Chars = new TCHAR[TextLen];

        GetWindowText(Window, Chars, TextLen);
        String Return(Chars);

        delete[] Chars;
        return Return;
    }
    void SetText(HWND Window, String New)
    {
        TCHAR* Chars = const_cast<TCHAR*>(New.c_str());

        SendMessage(Window, WM_SETTEXT, 0, reinterpret_cast<LPARAM>(Chars));
    }

    Control::Control(HINSTANCE ins)
    {
        _Base = nullptr;
        if (!Control::_ThisAtom)
            RegisterAtom(ins);

        if (!Control::_ThisAtom)
            throw std::logic_error("The atom for control could not be loaded!");
    }
    Control::~Control()
    {
        SetWindowLongPtr(_Base, GWLP_USERDATA, 0);
        DestroyWindow(_Base);
    }

    ATOM UI_API Control::_ThisAtom = ATOM();
    ID2D1Factory* UI_API Control::Factory = nullptr;

    bool Control::RegisterAtom(HINSTANCE ins)
    {

    }

    LRESULT __stdcall Control::CommonWndProc(HWND Window, UINT Message, WPARAM wp, LPARAM lp)
    {
        if (Message == WM_CREATE)
        {
            LPCREATESTRUCT lp = reinterpret_cast<LPCREATESTRUCT>(lp);
            if (lp->lpCreateParams)
            {
                Control* Conv = static_cast<Control*>(lp->lpCreateParams);
                Conv->OnCreate(lp);
                SetWindowLongPtr(Window, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(lp->lpCreateParams);
            }
        }

        LONG_PTR Value = GetWindowLongPtr(Window, GWLP_USERDATA);
        if (!Value)
            return DefWindowProc(Window, Message, wp, lp);

        Control* Data = reinterpret_cast<Control*>(Value);

        switch (Message)
        {
        case WM_PAINT:
            Data->OnPaint();
            return 0;
        case WM_DESTROY:
        {
            Data->OnDestroy();
            delete Data;
            return 0;
        }
        case WM_KEYDOWN:
            Data->OnKeyDown(wp);
            return 0;
        case WM_CHAR:
        {
            WORD VKCode = LOWORD(wp);

            WORD KeyFlags = HIWORD(lp);
            int ScanCode = LOBYTE(KeyFlags);
            bool IsExtendedKey = (KeyFlags & KF_EXTENDED) == KF_EXTENDED;

            if (IsExtendedKey)
                ScanCode = MAKEWORD(ScanCode, 0xE0);

            bool WasKeyDown = (KeyFlags & KF_REPEAT) == KF_REPEAT;
            WORD RepeatCount = LOWORD(lp);
            bool IsKeyReleased = (KeyFlags & KF_UP) == KF_UP;

            switch (VKCode)
            {
            case VK_SHIFT:
            case VK_CONTROL:
            case VK_MENU:
                VKCode = LOWORD(MapVirtualKey(ScanCode, MAPVK_VSC_TO_VK_EX));
            }

            Data->OnChar(static_cast<wchar_t>(VKCode), static_cast<int>(RepeatCount), static_cast<int>(ScanCode), IsExtendedKey, WasKeyDown, IsKeyReleased);
            return 0;
        }
        case WM_LBUTTONDOWN:
        {
            bool Focus = Data->FocusOnClick();
            Data->OnClick();
            if (Focus)
                SetFocus(Window);
            return 0;
        }
        case WM_RBUTTONDOWN:
        {
            Data->OnRightClick();
            return 0;
        }
        case WM_LBUTTONUP:
            Data->OnMouseUp();
            return 0;
        case WM_LBUTTONDBLCLK:
            Data->OnDoubleClick();
            return 0;
        case WM_RBUTTONDBLCLK:
            Data->OnRDoubleClick();
            return 0;
        case WM_TIMER:
            Data->OnTimerTick(static_cast<LONG>(wp));
            return 0;
        case WM_COMMAND:
        {
            Data->OnCommand(wp, lp);
            return 0;
        }
        case WM_SIZE:
        {
            LONG w = LOWORD(lp), h = HIWORD(lp);
            Data->OnSize(w, h);
            return 0;
        }
        case WM_MOVE:
        {
            LONG x = LOWORD(lp), y = HIWORD(lp);
            Data->OnMove(x, y);
            return 0;
        }
        case WM_SETFOCUS:
            Data->GotFocus();
            return 0;
        case WM_KILLFOCUS:
        {
            Data->LostFocus();
            SendMessage(GetParent(Window), Message, wp, lp);
            return 0;
        }
        case WM_ENABLE:
            Data->IsEnabled = wp;
        case WM_SHOWWINDOW:
            RedrawWindow(Window, NULL, NULL, RDW_ERASE | RDW_INVALIDATE);
            return 0;
        case WM_ERASEBKGND:
            return 1;

        default:
            return DefWindowProc(Window, Message, wp, lp);
        }
    }

    void Control::OnKeyDown(WPARAM key)
    {
        SendMessage(GetParent(_Base), WM_KEYDOWN, key, 0);
    }
    void Control::OnSize(LONG width, LONG height)
    {

    }
    void Control::OnMove(LONG x, LONG y)
    {

    }

    bool Control::Enabled() { return IsEnabled; }
    void Control::Enabled(bool New)
    {
        IsEnabled = New;
        EnableWindow(_Base, New);
        Redraw();
    }

    void Control::Redraw()
    {
        RedrawWindow(_Base, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASENOW);
    }
}
